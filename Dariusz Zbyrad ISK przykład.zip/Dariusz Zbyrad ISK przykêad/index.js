var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);


io.on('connection', function(socket){
  socket.on('eventName1', function(msg) {
    console.log('Receive eventName with data: ' + msg);
  })
});

setTimeout(function(){
  io.emit('eventName2', "Message");
}, 5000);

app.get('/', function(req, res){
  res.sendfile('index.html');
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});
